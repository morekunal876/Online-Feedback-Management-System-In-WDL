<?php include('Regi.php')?>
<!DOCTYPE html>
<html>
<head>
	<title>STUDENT REGISTRATION</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="css/bootstrap.theme.min.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet" type="text/css">

	<!-- <script rel="stylesheet" href="css/bootstrap.min.css" type="text/css"></script> -->

	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    

<style>
	body, html {
  		height: 100%;
  		margin: 0;
		}
.bg {
  /* The image used */
  background-image: url(img/C2.jpg);

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  
  background-repeat: no-repeat;
  background-size: cover;
}
	.icon{
		color: green;
	}
	.c{
		color: blue;
	}
	.c1{
		color: red;
	}
</style>


</head>
<body>

<form class="form-horizontal bg" id="validateForm" action="reg.php" method="POST" autocomplete="off">
	<section style="padding-top: 30px; padding-bottom: 20px;">
		<center><h2><label class="c">STUDENT REGISTRATION</label></h2></center>
	</section>
<div class="row">
	<div class="col-md-offset-1 col-md-4">
		<div <?php if (isset($name_error)): ?> class="form_error" <?php endif ?> >
		  <div class="form-group">
			<label class="control-label c">Full Name:</label>
			 <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user icon"></i></span>
			<input  name="full_name" placeholder="Full Name" class="form-control"  type="text" value="<?php error_reporting(0); echo $full_name;?>">
		</div>
		  </div>
		<?php if (isset($name_error)): ?>
	  	<span class="c1"><?php echo $name_error; ?></span>
		<?php endif?>
		</div>
		  
		<div <?php if (isset($grno_error)): ?> class="form_error" <?php endif ?> >
		  <div class="form-group">
			<label class="control-label c">GR number:</label>
			<div class="input-group">
			<span class="input-group-addon"><i class="glyphicon glyphicon-pencil icon"></i></span>
			<input name="grno" placeholder=" enter grno" class="form-control" type="text" value="<?php echo $grno ; error_reporting(0);?>">
		</div>
		  </div>
		<?php if (isset($grno_error)): ?>
	  	<span class="c1"><?php echo $grno_error; ?></span>
		  <?php endif?>
		</div>
		  
		  <!-- <div class="form-group">
			<label class="control-label">Date Of birth:</label>
			<input type="date" class="form-control" name="DOB">
		  </div> -->
		  <div <?php if (isset($email_error)): ?> class="form_error" <?php endif ?> >
		  <div class="form-group">
			<label class="control-label c">E-Mail:</label>
			<div class="input-group">
			<span class="input-group-addon"><i class="glyphicon glyphicon-envelope icon"></i></span>
			<input name="email" placeholder="E-Mail" class="form-control"  type="text" value="<?php echo $email; error_reporting(0);?>">
		  </div>
		  </div>
		<?php if (isset($email_error)): ?>
      	<span class="c1"><?php echo $email_error; ?></span>
		<?php endif?>
		</div>
		  
		  <div class="form-group">
			<label class="control-label c">Department:</label>
			<div class="input-group">
             <span class="input-group-addon"><i class="glyphicon glyphicon-education icon"></i></span>
			<select class="form-control" name="Branch">
				<option></option>
				<option>COMPUTER</option>
				<option>IT</option>
				<option>CIVIL</option>
				<option>MECHANICAL</option>
				<option>AUTOMOBILE</option>
				<option>EXTC</option>
			</select>
			</div>
		  </div>
		
	</div>
	<div class="col-md-offset-1 col-md-4">
		

		  <div class="form-group">
		  	<label class="control-label c">Admission year:</label>
		  	<div class="input-group">
        	<span class="input-group-addon"><i class="glyphicon glyphicon-calendar icon"></i></span>
		  	<input type="number" name="Adyr" placeholder="Enter your admission year" class="form-control">
		  </div>
		  </div>
		  
		<div class="form-group has-feedback">
			<label for="password"  class="control-label c">Password</label>
			 <div class="input-group">
             <span class="input-group-addon"><i class="glyphicon glyphicon-lock icon"></i></span>
			<input class="form-control" id="userPw" type="password" placeholder="password" name="password"  />
		</div>
		</div>
	 
		<div class="form-group has-feedback">
			<label for="confirmPassword"  class="control-label c"> Confirm Password </label>
			 <div class="input-group">
             <span class="input-group-addon"><i class="glyphicon glyphicon-lock icon"></i></span>
			 <input class="form-control" id="userPw2" type="password" placeholder="Confirm password" name="confirmPassword" /> 
			</div>
		</div>
		  
	</div>
</div>

		<section style="padding-top: 30px;">
			<center><div class="form-group">
			<button type="submit" name="register" class="btn btn-success" >Submit</button>
		  </div></center>
		</section>


</form>

<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.4.5/js/bootstrapvalidator.min.js'></script>

<script type="text/javascript">
	

$('#validateForm').bootstrapValidator({
feedbackIcons: {
	valid: 'glyphicon glyphicon-ok',
	invalid: 'glyphicon glyphicon-remove',
	validating: 'glyphicon glyphicon-refresh'
},
fields: {
	full_name: {
		validators: {
			stringLength: {
				min: 5,
				pattern:"/^[a-zA-Z- ]/",
				message: 'Please Enter your Full name with minimum 5 letters length'
			},
			notEmpty: {
				message: 'Please Enter your Full name'
			}
		}
	},

	grno:{
		validators:{
			notEmpty:'Please enter your gr number'
		}
	},
	/*phone: {
		validators: {
			numeric: {
				message: 'The phone no must be a number'
			},
			notEmpty: {
				message: 'Please Enter your phone number'
			}
		}
	},*/
	/*address: {
		validators: {
			stringLength: {
				min: 15,
				max: 100,
				message:'Please enter at least 15 characters and no more than 100'
			},
			notEmpty: {
				message: 'Please Enter Address'
			}
		}
	},*/
	 /*DOB: {
                validators: {
                    date: {
                    	pattern: '/^\d{2}\/\d{2}\/\d{4}$/',
                        format: 'DD/MM/YYYY',
                        message: 'The format is dd/mm/yyyy'
                    },
                    notEmpty: {
                        message: 'The field can not be empty'
                    }
                }
            },*/
    email: {
		validators: {
			notEmpty: {
				message: 'Please Enter your email address'
			},
			emailAddress: {
				message: 'Please Enter a valid email address'
			}
		}
	},
	Branch: {
		validators: {
			notEmpty: {
				message: 'The Branch option is required'
			}
		}
	},
	
	Adyr:{
		validators:{
			numeric: {
				message: 'The Admission year must be a number'
			},
			notEmpty: {
				message: 'Please Enter your Admission year'
			}
		}
	},
	password: {
		validators: {
			notEmpty: {
				message: 'Enter your profile password'
			}
		}
	},
	confirmPassword: {
		validators: {
			notEmpty: {
				message: 'Enter confirm your profile password'
			},
			identical: {
				field: 'password',
				message: 'Enter the password, what enter in password field'
			}
		}
	 },
/*	 'lang_known[]': {
		validators: {
			notEmpty: {
				message: 'The Language Known is required'
			}
		}
	},
	role: {
		validators: {
			notEmpty: {
				message: 'Choose your user role'
			}
		}
	},*/
	
	}
});

</script>

</body>
</html>