<?php

$servername="localhost";
$username="root";
$dbname="feedback";
$password="";

session_start();
$sem=$_SESSION['sem'];
$bt=$_SESSION['bt'];

$conn=new mysqli($servername, $username, $password, $dbname);

	if ($conn->connect_error){
		die("Connection failed:" .$conn->connect_error);
	}

 /*$sql="select * from theory_subjects where sem_no=$sem";
	$query=mysqli_query($conn, $sql);
while($row=mysqli_fetch_assoc($query)){
	echo $row["subject_name"];
}*/


?>