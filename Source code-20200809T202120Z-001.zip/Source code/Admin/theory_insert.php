<?php

include 'conn.php';

if(isset($_POST['done'])){

 $sem_no = $_POST['sem_no'];
 $subject_code = $_POST['subject_code'];
 $subject_name=$_POST['subject_name'];
 $faculty_name=$_POST['faculty_name'];

 $q = " INSERT INTO `theory_subjects`(`sem_no`, `subject_code`, `subject_name`, `faculty_name`) VALUES ('$sem_no','$subject_code','$subject_name','$faculty_name')";
 echo $q;
 $query = mysqli_query($conn,$q);
 header('location:theory_display.php');
}
?>

<!DOCTYPE html>
<html>
<head>
 <title></title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">  Insert Operation </h1>
 </div><br>

 <label> Sem: </label>
 <input type="text" name="sem_no" id="sem" class="form-control"> 
 <h6 id="semcheck"></h6>
 <br>

 <label> Subject_code: </label>
 <input type="text" name="subject_code" id="subcode" class="form-control">
 <h6 id="subcodecheck"></h6>
 <br>

 <label> Subject_name: </label>
 <input type="text" name="subject_name" id="sub" class="form-control"> 
 <h6 id="subcheck"></h6>
 <br>

 <label> Faculty_name: </label>
 <input type="text" name="faculty_name" id="facname" class="form-control">
 <h6 id="facnamecheck"></h6>
 <br>

 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>

 </div>
 </form>
 </div>

 <script type="text/javascript">

 	$('document').ready(function(){
 		$('#semcheck').hide();
 		$('#subcodecheck').hide();
 		$('#subcheck').hide();
 		$('#facnamecheck').hide();

 		var sem_err=true;
 		var subcode_err=true;
 		var sub_err=true;
 		var facname_err=true;

 		$('#sem').keyup(function(){
 			sem_check();
 		})
 		function sem_check(){
 			var sem_val= $('#sem').val();

 			if(isNaN(sem_val)){
 				$('#semcheck').show();
 				$('#semcheck').html("*Please enter valid Semester number");
 				$('#semcheck').focus();
 				$('#semcheck').css("color","red");
 				sem_err=false;
 				return false;
 			}else{
 				$('#semcheck').hide();
 			}

 			if(sem_val.length>1){
 				$('#semcheck').show();
 				$('#semcheck').html("*Please enter valid Semester number");
 				$('#semcheck').focus();
 				$('#semcheck').css("color","red");
 				sem_err=false;
 				return false;
 			}else{
 				$('#semcheck').hide();
 			}
 		}

 		$('#subcode').keyup(function(){
 			subcode_check();
 		})
 		function subcode_check(){
 			var subcode_val=$('#subcode').val();

 			if(subcode_val.length<1){
 				$('#subcodecheck').show();
 				$('#subcodecheck').html("*Please enter subject code");
 				$('#subcodecheck').focus();
 				$('#subcodecheck').css("color","red");
 				subcode_err=false;
 				return false;
 			}else{
 				$('#subcodecheck').hide();
 			}
 		}

 		$('#sub').keyup(function(){
 			sub_check();
 		})
 		function sub_check(){
 			var sub_val=$('#sub').val();

 			if(!isNaN(sub_val)){
 				$('#subcheck').show();
 				$('#subcheck').html("*Please Enter valid subject name.");
 				$('#subcheck').focus();
 				$('#subcheck').css("color","red");
 				sub_err=false;
 				return false;
 			}else{
 				$('#subcheck').hide();
 			}
 		}

	 	$('#facname').keyup(function(){
	 		facname_check();
	 	})
	 	function facname_check(){
	 		var facname_val=$('#facname').val();

	 		if(!isNaN(facname_val)){
	 			$('#facnamecheck').show();
	 			$('#facnamecheck').html("**Please enter valid faculty name");
	 			$('#facnamecheck').focus();
	 			$('#facnamecheck').css("color","red");
	 			facname_err=false;
	 			return false;
	 		}else{
	 			$('facnamecheck').hide();
	 		}
	 	}
 	})
 	
 </script>

</body>
</html>
