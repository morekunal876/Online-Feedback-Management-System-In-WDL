<footer class="section">
		<div class="center grey-text"></div>
	</footer>
</body>