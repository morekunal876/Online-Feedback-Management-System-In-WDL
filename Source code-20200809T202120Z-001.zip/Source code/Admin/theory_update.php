<?php

 include 'conn.php';

 if(isset($_POST['done'])){

 $subject_code = $_POST['subject_code'];
 /*$sem_no=$_POST['sem_no'];
 $subject_name= $_POST['subject_name'];*/
 $faculty_name = $_POST['faculty_name'];

 $q = " update theory_subjects set faculty_name='$faculty_name' where subject_code='$subject_code' ";
echo $q;
 $query = mysqli_query($conn,$q);
 if($conn->connect_error)
	{
		die("Connectivity Error:".$conn->connect_error);
	}else {
		echo "connected";
	}

 header('location:theory_display.php');
 }

?>

<!DOCTYPE html>
<html>
<head>
 <title></title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">  Update Operation </h1>
 </div><br>

 <label> Sem: </label>
 <input type="text" name="sem_no" class="form-control"> <br>

 <label> Subject_code: </label>
 <input type="text" name="subject_code" class="form-control"> <br>
 <label> Subject_name: </label>
 <input type="text" name="subject_name" class="form-control"> <br>
 <label> Faculty_name: </label>
 <input type="text" name="faculty_name" class="form-control"> <br>

 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>

 </div>
 </form>
 </div>
</body>
</html>