<?php

$servername="localhost";
	$username="root";
	$password="";
	$dbname="feedback";
$conn=new mysqli($servername,$username,$password,$dbname);

$sql="select *from stuinfo";
$query=mysqli_query($conn,$sql);
if(mysqli_num_rows($query)>0){
	while($result=mysqli_fetch_array($query)){
		?>
		<tr>
			<td><?php echo $result['grno'] ?></td>
			<td><?php echo $result['name'] ?></td>
			<td><?php echo $result['phone'] ?></td>
			<td><?php echo $result['Adyr'] ?></td>
			<td><?php echo $result['DOB'] ?></td>
			<td><?php echo $result['age'] ?></td>
			<td><?php echo $result['dept'] ?></td>
			<td><?php echo $result['blogp'] ?></td>
			<td><?php echo $result['caste'] ?></td>
			<td><?php echo $result['subcaste'] ?></td>
		</tr>
<?php
	}
}
?>