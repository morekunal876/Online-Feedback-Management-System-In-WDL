
<?php


	$servername="localhost";
	$username="root";
	$password="";
	$dbname="feedback";

	$full_name=$_POST['fname'];
	$id=$_POST['fid'];
	$email=$_POST['email'];
	$Branch=$_POST['fbranch'];
	$pass=$_POST['pass2'];

	/*session_start();
	$_SESSION['full_name']=$full_name;
*/
	$conn=new mysqli($servername,$username,$password,$dbname);
	 if($conn->connect_error)
	 {
	 	die("connectivity Error:".$conn->connect_error);
	 }

	 $sql="insert into facregi(id,name,email,dept,password)values('$id','$full_name','$email','$Branch','$pass')";



	 if(mysqli_query($conn,$sql)){
	 	echo'<script>alert("Registration successfully");
            window.location = "faclogin.html";
            </script>';
	 }
	 else
	 {
	 	echo '<script>alert("Registration Failed");
            window.location = "facregi.html";
            </script>';
	 }
	 $conn->close();
?>
