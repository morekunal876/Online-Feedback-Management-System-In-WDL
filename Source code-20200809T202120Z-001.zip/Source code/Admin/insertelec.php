<?php

include 'conn.php';

if(isset($_POST['done'])){
echo $sem;
if($_POST['sem'] == ""){
	$error_msg['sem']="sem is required";
}
}

/*echo "hi";
$sem = $subject_code = $elective_subject = $faculty_name='';
/*$errorpr[]= array('' => , );
*/
//check for sem
// if(empty($_POST['sem'])){
// 	echo 'Enter sem';
// }else{
// 	$sem=$_POST['sem'];
// 	if(!filter_var($sem, FILTER_VALIDATE_INT)){
// 		echo "Semester should be in number";
// 	}
// }
// check foe subject code
/*if(empty($_POST['subject_code'])){
	echo 'Enter the subject code';
}else{
	$subject_code=$_POST['subject_code'];
	if(!filter_var('\w',$subject_code)){
		echo 'Subject code  must be a combination of alphabate and digits';
	}
}*/
//check for elective subject
/*if(empty($_POST['elective_subject'])){
	echo 'Enter the elective subject';
}else{
	$elective_subject=$_POST['elective_subject'];
	if(!preg_match('/^[a-zA-Z\s]+$/', elective_subject)){
		echo 'Enter the correct subject name must contain only alphabates ';
	}
}*/
//check for faculty name
// if(empty($_POST['faculty_name']))
// {
// 	echo 'Please enter faculty name';
// }else{
// 	$faculty_name=$_POST['faculty_name'];
// 	if(!preg_match('/^[a-zA-Z\s]+$/', faculty_name)){
// 		echo 'Faculty name must contain only alphabates';
// 	}
// }
 $sem = $_POST['sem'];
 $subject_code = $_POST['subject_code'];
 $elective_subject=$_POST['elective_subject'];
 $faculty_name=$_POST['faculty_name'];

 $q = " INSERT INTO `elec`(`sem`, `subject_code`, `elective_subject`, `faculty_name`) VALUES ('$sem','$subject_code','$elective_subject','$faculty_name')";
 echo $q;
 $query = mysqli_query($conn,$q);
 header('location:Displayelec.php');




?>
<!DOCTYPE html>
<html>
<head>
 <title></title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="col-lg-6 m-auto">
 
 <form action="insertelec.php" method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">  Insert Operation </h1>
 </div><br>

 <label> Sem: </label>
 <input type="text" name="sem" class="form-control" id="esem" >
 <?php if(isset($error_msg['sem'])){
 	echo "sem is required";
 }

 ?>
 <h6 id="semcheck"></h6>
 <br>

 <label> Subject_code: </label>
 <input type="text" name="subject_code" class="form-control" id="esubcode" required>
 <h6 id="subcodecheck"></h6>
 <br>

 <label> Elective_subject: </label>
 <input type="text" name="elective_subject" class="form-control" id="elecsub" required>
 <h6 id="elecsubcheck"></h6>
 <br>

 <label> Faculty_name: </label>
 <input type="text" name="faculty_name" class="form-control" id="facname" required>
 <h6 id="facnamecheck"></h6>
 <br>

 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>

 </div>
 </form>
 </div>
<!--  <script type="text/javascript">



 	$('document').ready(function(){
 		$('#semcheck').hide();
 		$('#subcodecheck').hide();
 		$('#elecsubcheck').hide();
 		$('#facnamecheck').hide();

 		var sem_err=true;
 		var subcode_err=true;
 		var elecsub_err=true;
 		var facname_err=true;

 		$('#esem').keyup(function(){
 			sem_check();
 		})
 		function sem_check(){
 			var sem_val= $('#esem').val();

 			if(isNaN(sem_val)){
 				$('#semcheck').show();
 				$('#semcheck').html("*Please enter valid Semester number");
 				$('#semcheck').focus();
 				$('#semcheck').css("color","red");
 				sem_err=false;
 				return false;
 			}else{
 				$('#semcheck').hide();
 			}

 			if(sem_val.length>1){
 				$('#semcheck').show();
 				$('#semcheck').html("*Please enter valid Semester number");
 				$('#semcheck').focus();
 				$('#semcheck').css("color","red");
 				sem_err=false;
 				return false;
 			}else{
 				$('#semcheck').hide();
 			}
 		}

 		$('#esubcode').keyup(function(){
 			subcode_check();
 		})
 		function subcode_check(){
 			var subcode_val=$('#esubcode').val();

 			if(subcode_val.length<1){
 				$('#subcodecheck').show();
 				$('#subcodecheck').html("*Please enter subject code");
 				$('#subcodecheck').focus();
 				$('#subcodecheck').css("color","red");
 				subcode_err=false;
 				return false;
 			}else{
 				$('#subcodecheck').hide();
 			}
 		}

 		$('#elecsub').keyup(function(){
 			elecsub_check();
 		})
 		function elecsub_check(){
 			var elecsub_val=$('#elecsub').val();

 			if(!isNaN(elecsub_val)){
 				$('#elecsubcheck').show();
 				$('#elecsubcheck').html("*Please Enter valid subject name.");
 				$('#elecsubcheck').focus();
 				$('#elecsubcheck').css("color","red");
 				elecsub_err=false;
 				return false;
 			}else{
 				$('#elecsubcheck').hide();
 			}
 		}

	 	$('#facname').keyup(function(){
	 		elecfacname_check();
	 	})
	 	function elecfacname_check(){
	 		var facname_val=$('#facname').val();

	 		if(!isNaN(facname_val)){
	 			$('#facnamecheck').show();
	 			$('#facnamecheck').html("**Please enter valid faculty name");
	 			$('#facnamecheck').focus();
	 			$('#facnamecheck').css("color","red");
	 			facname_err=false;
	 			return false;
	 		}else{
	 			$('facnamecheck').hide();
	 		}
	 	}
 	})
 	
 </script> 
 -->
 
</body>
</html>
