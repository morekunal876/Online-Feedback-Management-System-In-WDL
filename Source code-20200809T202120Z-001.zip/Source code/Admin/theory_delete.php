<?php

include 'conn.php';

$subject_code = $_GET['subject_code'];

$q = "DELETE FROM theory_subjects WHERE subject_code = '$subject_code'";
echo $q;
mysqli_query($conn,$q);

header('location:theory_display.php');

?>