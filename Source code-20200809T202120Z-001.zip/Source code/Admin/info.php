<?php  
$servername="localhost";
	$username="root";
	$password="";
	$dbname="feedback";

	$conn=new mysqli($servername,$username,$password,$dbname);

$sql = "SELECT * FROM stuinfo ORDER BY ASC";

$setRec = mysqli_query($conn, $sql); 
$columnHeader = '';  
$columnHeader = "Grno" . "\t" . "Name" . "\t" . "phone" . "\t"."Adyr"."\t"."DOB"."\t"."age"."\t"."dept"."\t"."blogp"."\t"."caste"."\t"."Subcaste"."\t";  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=User_Detail.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n"; 
 
?> 