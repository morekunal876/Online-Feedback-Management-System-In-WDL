<?php

include 'conn.php';

$subject_code = $_GET['subject_code'];

$q = "DELETE FROM elec WHERE subject_code = '$subject_code'";
echo $q;
mysqli_query($conn,$q);

header('location:Displayelec.php');

?>