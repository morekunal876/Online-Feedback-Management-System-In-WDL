<!DOCTYPE html>
<html>
<head>
	<title>display</title>

	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<style type="text/css">
	.colr{
		color: yellow;
	}
	.co{
		color: blue;
	}
</style>

</head>
<body>
	<div>
		<h3 class="mt-5 text-center bg-dark text colr">PRACTICAL SUBLECT</h3>
		<br>
		<!-- <button id="displayinfo" class="btn btn-danger">Display</button>

 -->
		<table class="table table-striped table-bordered text-center">
			<thead>
				<th class="co">subject</th>
				<th class="co">Faculty Name</th>
			</thead>
			<tbody id="response">
				
			</tbody>
		</table>
		<section>
			<center><button class="btn btn-success" onclick="window.location.href ='info.php';">Export To Excel</button>
		</center></section>
	</div>

	<script type="text/javascript">
		$(document).ready(function(){
			var from=$('#myform');
			$('#submit').click(function(){
				$.ajax(
				{
					url:from.attr("action"),
					type:'post',
					data:$("#myform input").serialize(),

					success:function(data){
						console.log(data);
					}

				});
			});
		

			Display();
		/*$('#displayinfo').click(function(){*/
			function Display(){
			$.ajax({
				url:'infoprac.php',
				type:'post',

				success:function(responsedata){
					$('#response').html(responsedata);
				}
			});
		}
		/*});*/
	});

	</script>

</body>
</html>