
<!DOCTYPE html>
		<html>
		<head>
			<title></title>
						<!-- Latest compiled and minified CSS -->
			<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

			<!-- jQuery library -->
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

			<!-- Popper JS -->
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

			<!-- Latest compiled JavaScript -->
			<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
		</head>
<body>
	<form class="container mt-5">
		<select class="form-control" id="selectsem" name="">
			<option value="0"></option>
			<option value="6">sem6</option>
			<option value="5">sem5</option>
		</select>

		<script>
	$(document).ready(function(){
    $("#selectsem").on('change', function() {
    	 if(this.value == "6"){
    	 	alert("#selectsem");
	      	$("#sub").show();
	      	$("#sub1").show();
	      	<?php $sem==6; ?>

	      }
	      if(this.value == "5"){
    	 	alert("#selectsem");
	      	$("#sub").hide();
	      	$("#sub1").hide();

	      }
	  });
     });


	</script>
</form>
</body>


<?php

	$servername="localhost";
	$username="root";
	$password="";
	$dbname="feedback";

	

if($sem==6){
	$semter='sem6';
	$semterelect='semelect6';
}
if($sem==5){
	$semter='sem5';
	$semterelect='';
}

	$conn=new mysqli($servername,$username,$password,$dbname);

$sql="select *from $semter";
$query=mysqli_query($conn,$sql);
if(mysqli_num_rows($query)>0){
	while($result=mysqli_fetch_array($query)){
		?>
			<div class="row">
				<div class="col-md-2" ></div>
				<div class="col-md-4">
					<label><?php echo $result['subject']; ?></label>
				</div>
				<div class="col-md-4">
					<label><?php echo $result['Faculty_Name']; ?></label>
				</div>
			</div>
		
		<?php
	}

}
?>
</form>
</body>
</html>
<?php  


$sql1="select *from $semterelect";
$query1=mysqli_query($conn,$sql1);

$query2=mysqli_query($conn,$sql1);


?>

<html>
<body>
	
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-4">
			 <select class="form-control" name="subject" style="display:none;" id="sub" required>
			 	<option ></option>
			 	<?php while($row1=mysqli_fetch_array($query1)):;?>
			 		<option><?php echo $row1['subject']; ?></option>
			 	<?php endwhile; ?>
			 </select>
		</div>
		<div class="col-md-4">
			<select class="form-control" name="Faculty_Name" style="display:none;"  id="sub1" required>
				<option></option>
			 	<?php while($row1=mysqli_fetch_array($query2)):;?>
			 		<option><?php echo $row1['Faculty_Name']; ?></option>
			 	<?php endwhile; ?>
			 </select>
		</div>
		
		
	</div>
	
</body>

</html>

