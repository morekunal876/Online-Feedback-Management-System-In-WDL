<?php  
$servername="localhost";
	$username="root";
	$password="";
	$dbname="feedback";

	$conn=new mysqli($servername,$username,$password,$dbname);

$sql = "SELECT * FROM stupointer ORDER BY ASC";

$setRec = mysqli_query($conn, $sql); 
$columnHeader = '';  
$columnHeader = "Grno" . "\t" . "Name" . "\t" . "Sem1" . "\t"."Sem2"."\t"."Sem3"."\t"."Sem4"."\t"."Sem5"."\t"."Sem6"."\t"."Sem7"."\t"."Sem8"."\t";  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=User_Detail.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n"; 
 
?> 