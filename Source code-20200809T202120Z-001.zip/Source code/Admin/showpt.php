<?php

$servername="localhost";
	$username="root";
	$password="";
	$dbname="feedback";
$conn=new mysqli($servername,$username,$password,$dbname);

$sql="SELECT * FROM stupointer ORDER BY ASC";
$query=mysqli_query($conn,$sql);
if(mysqli_num_rows($query)>0){
	while($result=mysqli_fetch_array($query)){
		?>
		<tr>
			<td><?php echo $result['grno'] ?></td>
			<td><?php echo $result['name'] ?></td>
			<td><?php echo $result['sem1'] ?></td>
			<td><?php echo $result['sem2'] ?></td>
			<td><?php echo $result['sem3'] ?></td>
			<td><?php echo $result['sem4'] ?></td>
			<td><?php echo $result['sem5'] ?></td>
			<td><?php echo $result['sem6'] ?></td>
			<td><?php echo $result['sem7'] ?></td>
			<td><?php echo $result['sem8'] ?></td>
		</tr>
<?php
	}
}
?>