
<?php
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="feedback";

	$name=$_POST['name']; 
	$grno=$_POST['grno'];
	$phone=$_POST['phone'];
	$Adyr=$_POST['Adyr'];
	$DOB=$_POST['DOB'];
	$age=$_POST['age'];     
	$dept=$_POST['dept'];
	$blogp=$_POST['blogp'];
	$caste=$_POST['caste'];
	$subcaste=$_POST['subcaste'];
	$swal='';


	session_start();
   	$_SESSION['name'] = "$name";
   	


   	$conn=new mysqli($servername,$username,$password,$dbname);



	
	
	
	if($conn->connect_error)
	{
		die("Connectivity Error:".$conn->connect_error);
	}
	else
	{
		$sql="insert into stuinfo(grno,name,phone,Adyr,DOB,age,dept,blogp,caste,subcaste)values('$grno','$name','$phone','$Adyr','$DOB','$age','$dept','$blogp','$caste','$subcaste')";

		if(mysqli_query($conn,$sql))
		{
			/*echo '<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js">
			swal({
	     	title:"successfully submitted",
          	icon:"success",
  			button:"ok",
       			 }); 
			</script>';*/


			echo'<script>alert("successfully submitted");
	 		 window.location = "point.html";
            </script>';
	 	}
		 else
	 	{
	 		echo '<script>alert("Failed submit");
            window.location = "studinfo.php";
            </script>';
	 	}
	 	
	}

	$conn->close();


?>
